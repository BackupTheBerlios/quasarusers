/*
 * $Id: STabbedPane.java,v 1.13 2002/05/15 16:16:23 hengels Exp $
 * (c) Copyright 2000 wingS development team.
 *
 * This file is part of wingS (http://wings.mercatis.de).
 *
 * wingS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * Please see COPYING for the complete licence.
 */

package org.wings;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.SingleSelectionModel;
import javax.swing.DefaultSingleSelectionModel;
import javax.swing.GrayFilter;
import javax.swing.ImageIcon;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.wings.plaf.*;
import org.wings.style.*;

// fixme: refactorize.
/**
 * A tabbed pane shows one tab (usually a panel) at a moment.
 * The user can switch between the panels.
 *
 * @author <a href="mailto:haaf@mercatis.de">Armin Haaf</a>
 * @version $Revision: 1.13 $
 */
public class STabbedPane 
    extends SContainer
    implements SConstants, SSelectionComponent
{
    /**
     * @see #getCGClassID
     */
    private static final String cgClassID = "TabbedPaneCG";

    /**
     * Where the tabs are placed.
     * @see #setTabPlacement
     */
    protected int tabPlacement = TOP;

    /** The default selection model */
    protected SingleSelectionModel model = new DefaultSingleSelectionModel();

    ArrayList pages = new ArrayList(2);

    /**
     * layout used to render the tabs. Only one tab is on top at a time.
     */
    final SCardLayout card = new SCardLayout();

    /**
     * container for all tabs. The card layout shows always one on
     * top.
     */
    final SContainer contents = new SPanel(card);

    /**
     * All tabs are buttons, that are handled in this button
     * group.
     */
    protected SButtonGroup group;


    /** the maximum tabs per line */
    protected int maxTabsPerLine = -1;

    SContainer buttons = new SPanel();
    ArrayList changeListener = new ArrayList(2);

    /** The style of selected tabs */
    protected Style selectionStyle;

    /** The dynamic attributes of selected tabs */
    protected AttributeSet selectionAttributes = new SimpleAttributeSet();


    /**
     * Creates a new empty Tabbed Pane with the tabs at the top.
     * @see #addTab
     */
    public STabbedPane() {
        this(TOP);
    }

    /**
     * Creates an empty TabbedPane with the specified tab placement
     * of either: TOP, BOTTOM, LEFT, or RIGHT.
     * @param tabPlacement the placement for the tabs relative to the content
     * @see #addTab
     */
    public STabbedPane(int tabPlacement) {
        super();

        SBorderLayout layout = new SBorderLayout();
        layout.setBorder(1);
        setLayout(layout);

        setTabPlacement(tabPlacement);

        super.addComponent(contents, SBorderLayout.CENTER, 0);

        group = new SButtonGroup();
        group.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    SAbstractButton button = group.getSelection();
                    for (int i=0; i < getTabCount(); i++) {
                        Page page = getPageAt(i);
                        if (button == page.button) {
                            setSelectedIndex(i);
                            fireStateChanged();
                            return;
                        }
                    }
                }
            });
    }

    /**
     * @param style the style of selected cells
     */
    public void setSelectionStyle(Style selectionStyle) {
        this.selectionStyle = selectionStyle;
    }

    /**
     * @return the style of selected cells.
     */
    public Style getSelectionStyle() { return selectionStyle; }

    /**
     * Set a selectionAttribute.
     * @param name the selectionAttribute name
     * @param value the selectionAttribute value
     */
    public void setSelectionAttribute(String name, String value) {
        boolean changed = selectionAttributes.contains(name);
        selectionAttributes.put(name, value);

        if (changed)
            reload(ReloadManager.RELOAD_STYLE);
    }

    /**
     * return the value of an selectionAttribute.
     * @param name the selectionAttribute name
     */
    public String getSelectionAttribute(String name) {
        return selectionAttributes.get(name);
    }

    /**
     * remove an selectionAttribute
     * @param name the selectionAttribute name
     */
    public String removeSelectionAttribute(String name) {
        if ( selectionAttributes.contains(name) ) {
            String value = selectionAttributes.remove(name);

            reload(ReloadManager.RELOAD_STYLE);

            return value;
        }

        return null;
    }


    /**
     * Set the selectionAttributes.
     * @param selectionAttributes the selectionAttributes
     */
    public void setSelectionAttributes(AttributeSet selectionAttributes) {
        if (selectionAttributes == null)
            throw new IllegalArgumentException("null not allowed");

        if (!this.selectionAttributes.equals(selectionAttributes)) {
            this.selectionAttributes = selectionAttributes;
            reload(ReloadManager.RELOAD_STYLE);
        }
    }

    /**
     * @return the current selectionAttributes
     */
    public AttributeSet getSelectionAttributes() {
        return selectionAttributes;
    }

    /**
     * Set the background color.
     * @param c the new background color
     */
    public void setSelectionBackground(Color color) {
        setSelectionAttribute("background-color", CSSStyleSheet.getAttribute(color));
    }

    /**
     * Return the background color.
     * @return the background color
     */
    public Color getSelectionBackground() {
        return CSSStyleSheet.getBackground(selectionAttributes);
    }

    /**
     * Set the foreground color.
     * @param c the new foreground color
     */
    public void setSelectionForeground(Color color) {
        setSelectionAttribute("color", CSSStyleSheet.getAttribute(color));
    }

    /**
     * Return the foreground color.
     * @return the foreground color
     */
    public Color getSelectionForeground() {
        return CSSStyleSheet.getForeground(selectionAttributes);
    }

    /**
     * Add a listener to the list of change listeners.
     * ChangeListeners are notified, when the tab selection changes.
     *
     * @param cl add to listener list
     */
    public void addChangeListener(ChangeListener cl) {
        if ( !changeListener.contains(cl) )
            changeListener.add(cl);
    }

    /**
     * Remove listener from the list of change listeners.
     * ChangeListeners are notified, when the tab selection changes.
     *
     * @param cl remove from listener list
     */
    public void removeChangeListener(ChangeListener cl) {
        changeListener.remove(cl);
    }

    /**
     * Fire ChangeEvents at all registered change listeners.
     */
    protected void fireStateChanged() {
        ChangeEvent ce = new ChangeEvent(this);
        for ( int i=0; i<changeListener.size(); i++ )
            ((ChangeListener)changeListener.get(i)).stateChanged(ce);
    }

    /**
     * Returns the placement of the tabs for this tabbedpane.
     * @see #setTabPlacement
     */
    public int getTabPlacement() {
        return tabPlacement;
    }

    /**
     * Sets the tab placement for this tabbedpane.
     * Possible values are:<ul>
     * <li>SConstants.TOP
     * <li>SConstants.BOTTOM
     * <li>SConstants.LEFT
     * <li>SConstants.RIGHT
     * </ul>
     * The default value is TOP.
     *
     * @param tabPlacement the placement for the tabs relative to the content
     *
     */
    public void setTabPlacement(int tabPlacement) {
        if ( tabPlacement != TOP && tabPlacement != LEFT &&
             tabPlacement != BOTTOM && tabPlacement != RIGHT ) {
            throw new IllegalArgumentException("illegal tab placement: must be TOP, BOTTOM, LEFT, or RIGHT");
        }

        this.tabPlacement = tabPlacement;
        super.removeComponent(buttons);

        switch ( tabPlacement ) {
        case TOP:
            super.addComponent(buttons, SBorderLayout.NORTH, 0);
            break;

        case BOTTOM:
            super.addComponent(buttons, SBorderLayout.SOUTH, 0);
            break;

        case LEFT:
            super.addComponent(buttons, SBorderLayout.WEST, 0);
            break;

        case RIGHT:
            super.addComponent(buttons, SBorderLayout.EAST, 0);
            break;
        }
    }

    /**
     * Returns the model associated with this tabbedpane.
     *
     * @see #setModel
     */
    public SingleSelectionModel getModel() {
        return model;
    }

    /**
     * Sets the model to be used with this tabbedpane.
     * @param model the model to be used
     *
     * @see #getModel
     */
    public void setModel(SingleSelectionModel model) {
        this.model = model;
    }

    /**
     * Returns the currently selected index for this tabbedpane.
     * Returns -1 if there is no currently selected tab.
     *
     * @return the index of the selected tab
     * @see #setSelectedIndex
     */
    public int getSelectedIndex() {
        return model.getSelectedIndex();
    }

    /**
     * Sets the selected index for this tabbedpane.
     *
     * @see #getSelectedIndex
     * @see SingleSelectionModel#setSelectedIndex
     * @beaninfo
     *   preferred: true
     * description: The tabbedpane's selected tab index.
     */
    public void setSelectedIndex(int index) {
        model.setSelectedIndex(index);

        Page p = getPageAt(index);
        if (p != null) {
            p.button.setSelected(true);
            card.show(p.component);
        }
    }

    /**
     * Returns the currently selected component for this tabbedpane.
     * Returns null if there is no currently selected tab.
     *
     * @return the component corresponding to the selected tab
     * @see #setSelectedComponent
     */
    public SComponent getSelectedComponent() {
        int index = getSelectedIndex();
        if ( index == -1 ) {
            return null;
        }
        return getTabAt(index);
    }

    /**
     * Sets the selected component for this tabbedpane.  This
     * will automatically set the selectedIndex to the index
     * corresponding to the specified component.
     *
     * @see #getSelectedComponent
     * @beaninfo
     *   preferred: true
     * description: The tabbedpane's selected component.
     */
    public void setSelectedComponent(SComponent c) {
        int index = indexOfComponent(c);
        if ( index != -1 ) {
            setSelectedIndex(index);
        }
        else {
            throw new IllegalArgumentException("component not found in tabbed pane");
        }
    }

    /**
     * Returns the index of the tab for the specified component.
     * Returns -1 if there is no tab for this component.
     * @param component the component for the tab
     */
    public int indexOfComponent(SComponent component) {
        for ( int i = 0; i < getTabCount(); ++i ) {
            if ( contents.getComponentAt(i).equals(component) ) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Returns the number of tabs in this tabbedpane.
     *
     * @return an int specifying the number of tabbed pages
     */
    public int getTabCount() {
        return pages.size();
    }

    /**
     * Inserts a <i>component</i>, at <i>index</i>, represented by a
     * <i>title</i> and/or <i>icon</i>, either of which may be null.
     * Uses java.util.ArrayList internally, see insertElementAt()
     * for details of insertion conventions.
     * @param title the title to be displayed in this tab
     * @param icon the icon to be displayed in this tab
     * @param component The component to be displayed when this tab is clicked.
     * @param tip the tooltip to be displayed for this tab
     * @param index the position to insert this new tab
     *
     * @see #addTab
     * @see #removeTabAt
     */
    public void insertTab(String title, SIcon icon,
                          SComponent component, String tip,
                          int index) {

        SIcon disabledIcon = null;

        if (icon != null && icon instanceof SImageIcon) {
            disabledIcon = new SImageIcon(new ImageIcon(GrayFilter.createDisabledImage(((SImageIcon)icon).getImage())));
        }

        String t = (title != null) ? title : "";

        Page p = new Page(this, t, icon, disabledIcon, component, tip);
        pages.add(index, p);

        contents.addComponent(p.component, p.component.getComponentId());

        if ( pages.size() == 1 ) {
            setSelectedIndex(0);
        }

        updateButtons();
    }

    /**
     * Adds a <i>component</i> and <i>tip</i> represented by a <i>title</i>
     * and/or <i>icon</i>, either of which can be null.
     * Cover method for insertTab().
     * @param title the title to be displayed in this tab
     * @param icon the icon to be displayed in this tab
     * @param component The component to be displayed when this tab is clicked.
     * @param tip the tooltip to be displayed for this tab
     *
     * @see #insertTab
     * @see #removeTabAt
     */
    public void addTab(String title, SIcon icon, SComponent component, String tip) {
        insertTab(title, icon, component, tip, pages.size());
    }

    /**
     * Adds a <i>component</i> represented by a <i>title</i> and/or <i>icon</i>,
     * either of which can be null.
     * Cover method for insertTab().
     * @param title the title to be displayed in this tab
     * @param icon the icon to be displayed in this tab
     * @param component The component to be displayed when this tab is clicked.
     *
     * @see #insertTab
     * @see #removeTabAt
     */
    public void addTab(String title, SIcon icon, SComponent component) {
        insertTab(title, icon, component, null, pages.size());
    }

    /**
     * Adds a <i>component</i> represented by a <i>title</i> and no icon.
     * Cover method for insertTab().
     * @param title the title to be displayed in this tab
     * @param component The component to be displayed when this tab is clicked.
     *
     * @see #insertTab
     * @see #removeTabAt
     */
    public void addTab(String title, SComponent component) {
        insertTab(title, null, component, null, pages.size());
    }


    /**
     * Adds a <i>component</i> with the specified tab title.
     * Cover method for insertTab().
     * @param title the title to be displayed in this tab
     * @param component The component to be displayed when this tab is clicked.
     *
     * @see #insertTab
     * @see #removeTabAt
     */
    public SComponent add(String title, SComponent component) {
        addTab(title, component);
        return component;
    }

    /**
     * Adds a <i>component</i> at the specified tab index.  If constraints
     * is a String or an Icon, it will be used for the tab title,
     * otherwise the component's name will be used as the tab title.
     * Cover method for insertTab().
     * @param component The component to be displayed when this tab is clicked.
     * @constraints the object to be displayed in the tab
     * @param index the position to insert this new tab
     *
     * @see #insertTab
     * @see #removeTabAt
     */
    public SComponent addComponent(SComponent component, 
                                   Object constraints) {
        return addComponent(component, constraints, pages.size());
    }

    /**
     * Adds a <i>component</i> at the specified tab index.  If constraints
     * is a String or an Icon, it will be used for the tab title,
     * otherwise the component's name will be used as the tab title.
     * Cover method for insertTab().
     * @param component The component to be displayed when this tab is clicked.
     * @constraints the object to be displayed in the tab
     * @param index the position to insert this new tab
     *
     * @see #insertTab
     * @see #removeTabAt
     */
    public SComponent addComponent(SComponent component, 
                                   Object constraints, int index) {
        SIcon icon = constraints instanceof SIcon ? (SIcon)constraints : null;
        String title = constraints instanceof String ? (String)constraints : null;
        insertTab(title, icon, component, null, Math.min(index, pages.size()));

        return component;
    }

    /**
     * Removes the tab at <i>index</i>.
     * After the component associated with <i>index</i> is removed,
     * its visibility is reset to true to ensure it will be visible
     * if added to other containers.
     * @param index the index of the tab to be removed
     *
     * @see #addTab
     * @see #insertTab
     */
    public void removeTabAt(int index) {
        // If we are removing the currently selected tab AND
        // it happens to be the last tab in the bunch, then
        // select the previous tab
        int tabCount = getTabCount();
        int selected = getSelectedIndex();
        if ( selected >= (tabCount - 1) ) {
            setSelectedIndex(selected - 1);
        }

        removePageAt(index);
        updateButtons();
    }

    /**
     * Removes the tab which corresponds to the specified component.
     *
     * @param component the component to remove from the tabbedpane
     * @see #addTab
     * @see #removeTabAt
     */
    public boolean removeComponent(SComponent component) {
        int index = indexOfComponent(component);
        if ( index != -1 ) {
            removeTabAt(index);
            return true;
        }

        return false;
    }

    /**
     * Sets the maximum tabs per line. tabs <= 0: No maximum.
     */
    public void setMaxTabsPerLine(int tabs) {
        maxTabsPerLine = tabs;
    }

    /**
     * Returns the maximum tabs per line.
     */
    public int getMaxTabsPerLine() {
        return maxTabsPerLine;
    }

    /**
     * Returns the tab title at <i>index</i>.
     *
     * @see #setTitleAt
     */
    public String getTitleAt(int index) {
        return getPageAt(index).title;
    }

    /**
     * Returns the tab icon at <i>index</i>.
     *
     * @see #setIconAt
     */
    public SIcon getIconAt(int index) {
        return getPageAt(index).icon;
    }

    /**
     * Returns the tab disabled icon at <i>index</i>.
     *
     * @see #setDisabledIconAt
     */
    public SIcon getDisabledIconAt(int index) {
        return getPageAt(index).disabledIcon;
    }

    /**
     * Returns the tab background color at <i>index</i>.
     *
     * @see #setBackgroundAt
     */
    public Color getBackgroundAt(int index) {
        return getPageAt(index).getBackground();
    }

    /**
     * Returns the tab foreground color at <i>index</i>.
     *
     * @see #setForegroundAt
     */
    public Color getForegroundAt(int index) {
        return getPageAt(index).getForeground();
    }

    /**
     * Returns the tab style at <i>index</i>.
     *
     * @see #setStyleAt
     */
    public Style getStyleAt(int index) {
        return getPageAt(index).getStyle();
    }

    /**
     * Returns whether or not the tab at <i>index</i> is
     * currently enabled.
     *
     * @see #setEnabledAt
     */
    public boolean isEnabledAt(int index) {
        return getPageAt(index).isEnabled();
    }

    /**
     * Returns the component at <i>index</i>.
     *
     * @see #setComponentAt
     */
    public SComponent getTabAt(int index) {
        return getPageAt(index).component;
    }

    /**
     * Sets the title at <i>index</i> to <i>title</i> which can be null.
     * An internal exception is raised if there is no tab at that index.
     * @param index the tab index where the title should be set
     * @param title the title to be displayed in the tab
     *
     * @see #getTitleAt
     */
    public void setTitleAt(int index, String title) {
        getPageAt(index).title = title;
    }

    /**
     * Sets the icon at <i>index</i> to <i>icon</i> which can be null.
     * An internal exception is raised if there is no tab at that index.
     * @param index the tab index where the icon should be set
     * @param icon the icon to be displayed in the tab
     *
     * @see #getIconAt
     */
    public void setIconAt(int index, SIcon icon) {
        getPageAt(index).icon = icon;
    }

    /**
     * Sets the disabled icon at <i>index</i> to <i>icon</i> which can be null.
     * An internal exception is raised if there is no tab at that index.
     * @param index the tab index where the disabled icon should be set
     * @param icon the icon to be displayed in the tab when disabled
     *
     * @see #getDisabledIconAt
     */
    public void setDisabledIconAt(int index, SIcon disabledIcon) {
        getPageAt(index).disabledIcon = disabledIcon;
    }

    /**
     * Sets the background color at <i>index</i> to <i>background</i>
     * which can be null, in which case the tab's background color
     * will default to the background color of the tabbedpane.
     * An internal exception is raised if there is no tab at that index.
     * @param index the tab index where the background should be set
     * @param background the color to be displayed in the tab's background
     *
     * @see #getBackgroundAt
     */
    public void setBackgroundAt(int index, Color background) {
        getPageAt(index).setBackground(background);
    }

    /**
     * Sets the foreground color at <i>index</i> to <i>foreground</i>
     * which can be null, in which case the tab's foreground color
     * will default to the foreground color of this tabbedpane.
     * An internal exception is raised if there is no tab at that index.
     * @param index the tab index where the foreground should be set
     * @param foreground the color to be displayed as the tab's foreground
     *
     * @see #getForegroundAt
     */
    public void setForegroundAt(int index, Color foreground) {
        getPageAt(index).setForeground(foreground);
    }

    /**
     * Sets the style at <i>index</i> to <i>style</i>
     * which can be null, in which case the tab's style
     * will default to the style of this tabbedpane.
     * An internal exception is raised if there is no tab at that index.
     * @param index the tab index where the style should be set
     * @param foreground the style to be used as the tab's style
     *
     * @see #getStyleAt
     */
    public void setStyleAt(int index, Style style) {
        getPageAt(index).setStyle(style);
    }

    /**
     * Sets whether or not the tab at <i>index</i> is enabled.
     * An internal exception is raised if there is no tab at that index.
     * @param index the tab index which should be enabled/disabled
     * @param enabled whether or not the tab should be enabled
     *
     * @see #isEnabledAt
     */
    public void setEnabledAt(int index, boolean enabled) {
        getPageAt(index).setEnabled(enabled);
    }

    /**
     * Sets the component at <i>index</i> to <i>component</i>.
     * An internal exception is raised if there is no tab at that index.
     * @param index the tab index where this component is being placed
     * @param component the component for the tab
     *
     * @see #getComponentAt
     */
    public void setComponentAt(int index, SComponent component) {
        Page page = getPageAt(index);
        if ( component != page.component ) {
            if ( page.component != null ) {
                contents.removeComponent(page.component);
            }
            page.component = component;
            contents.addComponent(page.component, page.component.getComponentId());
        }
    }

    /**
     * Returns the first tab index with a given <i>title</i>,
     * Returns -1 if no tab has this title.
     * @param title the title for the tab
     */
    public int indexOfTab(String title) {
        for ( int i = 0; i < getTabCount(); i++ ) {
            if ( getTitleAt(i).equals( (title == null) ? "" : title) ) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Returns the first tab index with a given <i>icon</i>.
     * Returns -1 if no tab has this icon.
     * @param icon the icon for the tab
     */
    public int indexOfTab(SIcon icon) {
        for ( int i = 0; i < getTabCount(); i++ ) {
            if ( getIconAt(i).equals(icon) ) {
                return i;
            }
        }
        return -1;
    }

    private void removePageAt(int i) {
        Page p = getPageAt(i);
        group.remove(p.button);
        pages.remove(i);
        contents.removeComponent(p.component);
    }

    /**
     * TODO: documentation
     *
     */
    protected void updateButtons() {
        buttons.removeAll();
        group.removeAll();

        for (int i=0; i < getTabCount(); i++) {
            Page p = getPageAt(i);
            buttons.add(p.button);
            group.add(p.button);
        }
    }

    private Page getPageAt(int i) {
        if ( i >= 0 && i < pages.size() ) {
            return (Page)pages.get(i);
        }
        else {
            return null;
        }
    }

    private static class Page implements Serializable
    {
        String title;
        Color background;
        Color foreground;
        Style style;
        SIcon icon;
        SIcon disabledIcon;
        STabbedPane parent;
        SComponent component;
        SAbstractButton button;
        String tip;
        boolean enabled = true;

        public Page(STabbedPane parent, String title, SIcon icon,
                    SIcon disabledIcon, SComponent component, String tip) {
            this.title = title;
            this.icon = icon;
            this.disabledIcon = disabledIcon;
            this.parent = parent;
            this.component = component;
            this.tip = tip;

            // FIXME: this shouldn't be buttons.
            button = new SToggleButton(title);
            button.setShowAsFormComponent(false);
            button.setSelectedIcon(icon);
            button.setDisabledSelectedIcon(disabledIcon);
            button.setIcon(icon);
            button.setDisabledIcon(disabledIcon);
            button.setToolTipText(tip);
            button.setNoBreak(true);
        }

        /**
         * TODO: documentation
         *
         * @return
         */
        public Color getBackground() {
            return ((background != null) ? background : parent.getBackground());
        }

        /**
         * TODO: documentation
         *
         * @param c
         */
        public void setBackground(Color c) {
            background = c;
        }
        /**
         * TODO: documentation
         *
         * @return
         */
        public Color getForeground() {
            return ((foreground != null) ? foreground : parent.getForeground());
        }

        /**
         * TODO: documentation
         *
         * @param c
         */
        public void setForeground(Color c) {
            foreground = c;
        }

        /**
         * TODO: documentation
         *
         * @return
         */
        public Style getStyle() {
            return ((style != null) ? style : parent.getStyle());
        }

        /**
         * TODO: documentation
         *
         * @param c
         */
        public void setStyle(Style s) {
            style = s;
        }

        /**
         * TODO: documentation
         *
         * @return
         */
        public boolean isEnabled() {
            return enabled;
        }

        /**
         * TODO: documentation
         *
         * @param b
         */
        public void setEnabled(boolean b) {
            enabled = b;
            button.setEnabled(b);
        }

        /**
         * TODO: documentation
         *
         * @return
         */
        public boolean isVisible() {
            return parent.isVisible();
        }

        /**
         * TODO: documentation
         *
         * @param b
         */
        public void setVisible(boolean b) {
            parent.setVisible(b);
        }
    }

    public String getCGClassID() {
        return cgClassID;
    }

    public void setCG(TabbedPaneCG cg) {
        super.setCG(cg);
    }
}

/*
 * Local variables:
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * compile-command: "ant -emacs -find build.xml"
 * End:
 */
