/*
 * $Id: SCheckBox.java,v 1.12 2002/05/15 12:19:34 hzeller Exp $
 * (c) Copyright 2000 wingS development team.
 *
 * This file is part of wingS (http://wings.mercatis.de).
 *
 * wingS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * Please see COPYING for the complete licence.
 */

package org.wings;

import org.wings.plaf.*;
import org.wings.style.*;
import org.wings.io.Device;

/*
 * Checkboxen sind etwas besondere {@link SFormComponent}, denn
 * ihre eigentliche Identitaet ({@link #getUID}) steckt nicht im Name,
 * sondern im Value. Das ist deswegen so, weil in HTML Gruppen
 * durch den selben Namen generiert werden. Das ist natuerlich
 * problematisch. Eine anderes Problem, welches hier auftaucht ist,
 * das HTML immer nur rueckmeldet, wenn eine Checkbox markiert ist.
 * Deshalb wird hintenan immer ein Hidden Form Element gehaengt,
 * welches rueckmeldet, dass die Checkbox bearbeitet wurde.
 */
/**
 * TODO: documentation
 *
 * @author <a href="mailto:armin.haaf@mercatis.de">Armin Haaf</a>
 * @version $Revision: 1.12 $
 */
public class SCheckBox extends SAbstractButton
{
    private static final String cgClassID = "CheckBoxCG";

    /**
     * TODO: documentation
     *
     */
    public SCheckBox() {
        this(false);
    }

    /**
     * create a checkbox with a text-label.
     *
     * @param text
     */
    public SCheckBox(String text) {
        this(false);
        setText(text);
    }

    /**
     * TODO: documentation
     *
     * @param selected
     */
    public SCheckBox(boolean selected) {
        setSelected(selected);

        setHorizontalTextPosition(NO_ALIGN);
        setVerticalTextPosition(NO_ALIGN);

        super.setType(CHECKBOX);
    }

    /**
     * TODO: documentation
     *
     * @param t
     */
    public final void setType(String t) {
        if ( !CHECKBOX.equals(t) )
            throw new IllegalArgumentException("type change not supported, type is fix: radiobutton");
        
        super.setType(t);
    }

    public String getCGClassID() {
        return cgClassID;
    }

    public void setCG(CheckBoxCG cg) {
        super.setCG(cg);
    }

}

/*
 * Local variables:
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * compile-command: "ant -emacs -find build.xml"
 * End:
 */
