
for f in `grep -l "public void setCG(ComponentCG cg) {" *.java` ; do
    COMP=`basename $f .java | sed 's/^S//g'`
    echo "#" ${COMP}
    echo "cat" S$COMP.java "| sed" "'s/public void setCG(ComponentCG cg) {/public void setCG("${COMP}"CG cg) {/g' >" S$COMP.java2 "; mv S$COMP.java2 S$COMP.java"
done
